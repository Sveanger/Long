---
name: 功能需求
about: 希望添加一个功能
title: ''
labels: ''
assignees: ''

---

请说明：

1. 加什么功能
2. 理由

提交 issue 前请删除这句话及上面的说明内容
