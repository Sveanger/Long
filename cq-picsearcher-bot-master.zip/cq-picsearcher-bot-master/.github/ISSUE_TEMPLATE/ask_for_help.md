---
name: 请求帮助
about: 例如无法正常部署等，请转至上方 discussions
title: ''
labels: ''
assignees: ''

---

如果不是汇报 bug 或请求新功能，请尽量不要提 issue，视情况我可能会直接关闭
