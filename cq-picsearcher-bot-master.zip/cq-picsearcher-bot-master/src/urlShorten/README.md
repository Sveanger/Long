# 短网址模块

## 正在使用的服务

| 服务   | 说明                                                                                |
| ------ | ----------------------------------------------------------------------------------- |
| oy.mk  | [Quan666/elf-dwz](https://github.com/Quan666/elf-dwz)                               |
| yww.uy | [Tsuk1ko/cfworker-url-shortener](https://github.com/Tsuk1ko/cfworker-url-shortener) |

## 不会使用的服务

| 服务    | 说明                                                                   |
| ------- | ---------------------------------------------------------------------- |
| t.cn    | 新浪已禁止个人使用                                                     |
| dwz.cn  | 百度已禁止个人使用                                                     |
| is.gd   | 墙了                                                                   |
| bit.ly  | 墙了                                                                   |
| sina.lt | 带 cookie PHPSESSID 鉴权，并且不是白名单内的网址跳转需要确认，过于麻烦 |
